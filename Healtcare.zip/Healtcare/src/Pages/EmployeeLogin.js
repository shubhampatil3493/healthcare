import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './EmployeeLogin.css';

import NavbarLog from '../Components/NabarLog';

function EmployeeLogin({ }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();

        // Basic form validation
        if (!username || !password) {
            setError('Both username and password are required');
            return;
        }

        // Assuming you have an API endpoint to handle employee login
        axios.post('http://localhost:3001/employee/login', { username, password })
            .then(result => {
                // setUser(result.data); // Assuming result.data contains user information
                navigate('/home');
            })
            .catch(err => {
                console.log(err);
                setError('Incorrect username or password');
            });
    };

    return (
       <div> <NavbarLog/> 
        <div className="login-container">
           
            <div className="login-content">
            <h1 style={{ fontSize: '3.5rem', textAlign: 'center' }}>Employee Login</h1>
<br></br>
                {error && <p className="error-message">{error}</p>}
                <form onSubmit={handleSubmit}>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Username" 
                            value={username}
                            onChange={(e) => setUsername(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="password" 
                            placeholder="Enter Password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} 
                        />
                    </div>
                    <button type="submit">Login</button>
                </form>
                <p>Don't have an account? <Link to="/Signup">Signup</Link></p>
            </div>
        </div></div>
    );
}

export default EmployeeLogin;
