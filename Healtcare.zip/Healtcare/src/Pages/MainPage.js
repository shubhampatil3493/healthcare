import React from 'react'
import HomePage from '../Components/HomePage'

function MainPage() {
  return (
    <div>
      <HomePage/>
    </div>
  )
}

export default MainPage
