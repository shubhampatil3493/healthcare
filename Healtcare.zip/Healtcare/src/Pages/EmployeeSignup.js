import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './EmployeeSignup.css';
import NavbarLog from '../Components/NabarLog';

function EmployeeSignup() {
    const [name, setName] = useState('');
    const [employeeId, setEmployeeId] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [gender, setGender] = useState('');
    const [department, setDepartment] = useState('');
    const [designation, setDesignation] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Basic form validation
        if (!name || !employeeId || !department || !designation || !email || !phone || !username || !password || !confirmPassword) {
            setError('All fields are required');
            return;
        }

        if (password !== confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        try {
            // Make a POST request to the backend API endpoint /register
            const response = await axios.post('http://localhost:3001/employee/register', {
                name,
                employeeId,
                dateOfBirth,
                gender,
                department,
                designation,
                email,
                phone,
                username,
                password
            });

            console.log(response.data); // Log the response from the backend
            navigate('/employee-login'); // After successful submission, navigate to the login page
        } catch (error) {
            console.error('Registration error:', error);
            setError('Registration failed. Please try again.'); // Set error message if registration fails
        }
    };

    return (
        <div>
        <NavbarLog/>
        <div className="signup-container">
            <div className="signup-content">
                
                <div className="form-container">
                    <h2>Signup</h2>
                    {error && <p className="error-message">{error}</p>}
                    <form onSubmit={handleSubmit}>
                        {/* Input fields */}
                        <div className="form-group">
                            <input 
                                type="text" 
                                placeholder="Enter Name" 
                                value={name}
                                onChange={(e) => setName(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="text" 
                                placeholder="Enter Employee ID" 
                                value={employeeId}
                                onChange={(e) => setEmployeeId(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="text" 
                                placeholder="Enter Date of Birth" 
                                value={dateOfBirth}
                                onChange={(e) => setDateOfBirth(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="text" 
                                placeholder="Enter Gender" 
                                value={gender}
                                onChange={(e) => setGender(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <select 
                                value={department}
                                onChange={(e) => setDepartment(e.target.value)}
                            >
                                <option value="">Select Department</option>
                                <option value="Front Desk">Front Desk</option>
                                <option value="Nursing">Nursing</option>
                                <option value="Administrative">Administrative</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <select 
                                value={designation}
                                onChange={(e) => setDesignation(e.target.value)}
                            >
                                <option value="">Select Designation</option>
                                <option value="Doctor">Doctor</option>
                                <option value="Receptionist">Receptionist</option>
                                <option value="Wardboy">Wardboy</option>
                            </select>
                        </div>
                        <div className="form-group">
                            <input 
                                type="email" 
                                placeholder="Enter Email" 
                                value={email}
                                onChange={(e) => setEmail(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="text" 
                                placeholder="Enter Phone Number" 
                                value={phone}
                                onChange={(e) => setPhone(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="text" 
                                placeholder="Enter Username" 
                                value={username}
                                onChange={(e) => setUsername(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="password" 
                                placeholder="Enter Password" 
                                value={password}
                                onChange={(e) => setPassword(e.target.value)} 
                            />
                        </div>
                        <div className="form-group">
                            <input 
                                type="password" 
                                placeholder="Confirm Password" 
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)} 
                            />
                        </div>
                        <button type="submit">Signup</button>
                    </form>
                    <p>Already have an account? <Link to="/login">Login</Link></p>
                </div>
                
            </div>
            
        </div></div>
    );
}

export default EmployeeSignup;
