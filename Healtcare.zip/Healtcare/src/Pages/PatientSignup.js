import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './PatientSignup.css'; 
import axios from 'axios';
import NavbarLog from '../Components/NabarLog';


function PatientSignup() {
    const [name, setName] = useState('');
    const [dateOfBirth, setDateOfBirth] = useState('');
    const [gender, setGender] = useState('');
    const [address, setAddress] = useState('');
    const [pinCode, setPinCode] = useState('');
    const [phone, setPhone] = useState('');
    const [email, setEmail] = useState('');
    const [bloodGroup, setBloodGroup] = useState('');
    const [maritalStatus, setMaritalStatus] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [verifyPassword, setVerifyPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e)  => {
        e.preventDefault();

        if (!name || !dateOfBirth || !gender || !address || !pinCode || !phone || !username || !password || !verifyPassword) {
            setError('All required fields must be filled');
            return;
        }

        if (password !== verifyPassword) {
            setError('Passwords do not match');
            return;
        }

        try {
            // Make a POST request to the backend API endpoint /employee/register
            const response = await axios.post('http://localhost:3001/patient/register', {
                name,
                dateOfBirth,
                gender,
                address,
                pinCode,
                phone,
                email,
                bloodGroup,
                maritalStatus,
                username,
                password
            });

            console.log(response.data); // Log the response from the backend
            navigate('/patient-login'); // After successful submission, navigate to the login page
        } catch (error) {
            console.error('Registration error:', error);
            setError('Registration failed. Please try again.'); // Set error message if registration fails
        }

    };

    return (
        <div><NavbarLog/>
        <div className="signup-container">
            <div className="signup-content">
                {error && <p className="error-message">{error}</p>}
                
                <form onSubmit={handleSubmit}>
                <p>Already have an account? <Link to="/patient-login">Login</Link></p>
                    <h2>Patient Signup</h2>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Name" 
                            value={name}
                            onChange={(e) => setName(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Date of Birth (YYYY-MM-DD)" 
                            value={dateOfBirth}
                            onChange={(e) => setDateOfBirth(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Gender" 
                            value={gender}
                            onChange={(e) => setGender(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Address" 
                            value={address}
                            onChange={(e) => setAddress(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter PIN Code" 
                            value={pinCode}
                            onChange={(e) => setPinCode(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Phone Number" 
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="email" 
                            placeholder="Enter Email (Optional)" 
                            value={email}
                            onChange={(e) => setEmail(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Blood Group (Optional)" 
                            value={bloodGroup}
                            onChange={(e) => setBloodGroup(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Marital Status (Optional)" 
                            value={maritalStatus}
                            onChange={(e) => setMaritalStatus(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="text" 
                            placeholder="Enter Username" 
                            value={username}
                            onChange={(e) => setUsername(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="password" 
                            placeholder="Enter Password" 
                            value={password}
                            onChange={(e) => setPassword(e.target.value)} 
                        />
                    </div>
                    <div className="form-group">
                        <input 
                            type="password" 
                            placeholder="Verify Password" 
                            value={verifyPassword}
                            onChange={(e) => setVerifyPassword(e.target.value)} 
                        />
                    </div>
                    <button type="submit">Signup</button>
                </form>
                
            </div>
        </div></div>
    );
}

export default PatientSignup;
