import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import NavbarLog from '../Components/NabarLog';

function PatientLogin({ }) {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post('http://localhost:3001/patient/login', { username, password })
            .then(result => {
                // setUser(result.data.user);
                navigate('/Home');
                
            })
            .catch(err => console.log(err));
    };

    return (
        <div>
            <NavbarLog/>
       
        <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            height: '100vh', 
            background: 'linear-gradient(to right, #d9abd7, #ff5e62)' 
        }}>
            <div style={{ 
                background: 'white', 
                padding: '20px', 
                borderRadius: '10px', 
                width: '25%', 
                boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
                textAlign: 'center'
            }}>
                <h2 style={{ marginBottom: '20px', color: '#ff5e62' }}>Patient Login</h2>
                <form onSubmit={handleSubmit}>
                    <div style={{ marginBottom: '15px' }}>
                        <input 
                            type="username" 
                            placeholder="username" 
                            autoComplete="off" 
                            name="username" 
                            style={{ 
                                width: '100%', 
                                padding: '10px', 
                                borderRadius: '5px', 
                                border: '1px solid #ccc' 
                            }} 
                            onChange={(e) => setUsername(e.target.value)} 
                        />
                    </div>
                    <div style={{ marginBottom: '15px' }}>
                        <input 
                            type="password" 
                            placeholder="Enter Password" 
                            name="password" 
                            style={{ 
                                width: '100%', 
                                padding: '10px', 
                                borderRadius: '5px', 
                                border: '1px solid #ccc' 
                            }} 
                            onChange={(e) => setPassword(e.target.value)} 
                        />
                    </div>
                    <button 
                        type="submit" 
                        style={{ 
                            width: '100%', 
                            padding: '10px', 
                            borderRadius: '5px', 
                            border: 'none', 
                            background: '#ff5e62', 
                            color: 'white', 
                            cursor: 'pointer' 
                        }}
                    >
                        Login
                    </button>
                </form>
                <p style={{ marginTop: '20px', fontSize: '14px', color: '#666' }}>Don't have an account?</p>
                <Link 
                    to="/patient-signup" 
                    style={{ 
                        display: 'block', 
                        width: '100%', 
                        padding: '10px', 
                        borderRadius: '5px', 
                        border: '1px solid #ccc', 
                        background: 'white', 
                        color: '#666', 
                        textDecoration: 'none', 
                        textAlign: 'center',
                        cursor: 'pointer'
                    }}
                >   
                    Signup
                </Link>
            </div>
        </div> </div>
    );
}

export default PatientLogin;
