import React from "react";

import Footer from "../Components/Footer";
import HeroLog from "../Components/HeroLog";
import Info from "../Components/Info";
import NavbarLog from "../Components/NabarLog";

function Landing() {
  return (
    <div className="home-section">
     <NavbarLog/>
      <HeroLog/>
    <Info/>
      <Footer />
    </div>
  );
}

export default Landing;
