import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./Pages/Home";
import Legal from "./Pages/Legal";
import NotFound from "./Pages/NotFound";
import Appointment from "./Pages/Appointment";
import Landing from "./Pages/Landing";
import EmployeeLogin from "./Pages/EmployeeLogin";
import EmployeeSignup from "./Pages/EmployeeSignup";
import PatientLogin from "./Pages/PatientLogin";
import PatientSignup from "./Pages/PatientSignup";
import HomePage from "./Components/HomePage";

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="/" element={<Landing/>}/>
          <Route path="/employee-login" element={<EmployeeLogin/>}/>
          <Route path="/Signup" element={<EmployeeSignup/>}/>
          <Route path="/patient-login" element={<PatientLogin/>}/>
          <Route path="/patient-signup" element={<PatientSignup/>}/>
          <Route path="/MainPage" element={<HomePage/>}/>
          <Route path="/home" element ={<Home/>}/>
          <Route path="/legal" element={<Legal />} />
          <Route path="/appointment" element={<Appointment />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
